
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no"/>
<title>Jejak Pengerjaan Project</title>
<style>
body {
color: #333;
font-family: sans-serif;
font-size: 12px;
font-size-adjust: none;
line-height: 1.25em;
padding: 0 1%;
}
p {
line-height: 1.35em;
text-align: justify;
word-spacing: .25em;
}
ul {
padding: 20px 65px 10px 40px;
text-align: justify;
}
ul li.t {
font-size: 1.3em;
}
ul li.t.b {
font-size: 1.1em;
}
ul li.t, dl dt {
font-weight: 500;
position: relative;
}
dl {
margin: 20px 0 30px 30px;
}
dl dt {
font-size: 1em;
}
dl dd {
color: #333;
font-size: .9em;
margin-left: 0;
}
@media(max-width: 768px){
ul {
padding: 10px 23px 5px 15px;
}
dl {
margin: 8px 0 10px 10px;
}
}
</style>
</head>
<body>
<h1>Jejak Pengerjaan</h1>
<h2>1. Folder & File</h2>
<ul>
<li class="t">Folder</li>
<ul>
<li class="t b">data / file / img</li>
<dl>
<dt>Data</dt>
<dd>Data -&gt; adalah folder yang dimana didalamnya terdapat dua buah folder turunannya yaitu folder file dan satu lagi folder img.</dd>
</dl>
<dl>
<dt>File</dt>
<dd>File -&gt; adalah folder turunan dari folder data yang didalamnya terdapat satu buah sub folder yang benama img.</dd>
</dl>
<dl>
<dt>Img</dt>
<dd>Img -&gt; adalah sub folder dari folder file dan folder untuk menyimpan gambar posting yang di upload dari halaman dashboard.</dd>
</dl>
<li class="t b">f / g</li>
<dl>
<dt>F</dt>
<dd>F -&gt; adalah folder yang memiliki satu buah sub folder yaitu g, dan folder g ini adalah tempat untuk menampung file gambar khusus.</dd>
</dl>
<dl>
<dt>G</dt>
<dd>G -&gt; adalah folder untuk menyimpan gambar yang diupload khusus atau langsung dari halaman file manager di cpanel.</dd>
</dl>
<li class="t b">files / images</li>
<dl>
<dt>Files</dt>
<dd>Files -&gt; adalah sebuah folder yang memiliki satu buah sub folder didalamnya yaitu folder images untuk menampung gambar posting yang berhasil diupload.</dd>
</dl>
<dl>
<dt>Images</dt>
<dd>Images -&gt; adalah folder untuk menyimpan gambar sampul dari masing-masing posting yang diupload langsung ketika membuat atau edit posting.</dd>
</dl>
</ul>
<li class="t">File</li>
<dl>
<dd>Semua file dibawah ini berekstensi .php kecuali .htaccess, dan semuanya tersimpan pada satu direktori yang sama termasuk .htaccess file.</dd>
</dl>
<dl>
<dd>Dan sebelumnya akan sedikit menjelaskan, sebenarnya website ini memiliki 2 bagian data, yang satu bagiannya bersifat privat diperuntukan khusus untuk anggota, dan satu bagiannya lagi bersifat terbuka.</dd>
</dl>
<dl>
<dd>Untuk yang bersifat terbuka dibagi lagi menjadi 2 bagian, yang satunya bersifat publik dapat diakses oleh siapa saja, dan yang satu bagian lagi membutuhkan akses dan hanya dapat diakses oleh pengguna yang telah terdaftar dan aktif.</dd>
</dl>
<dl>
<dt>.htaccess</dt>
<dd>File .htaccess adalah sebuah file untuk pretty URL atau konfigurasi ulang URL agar terlihat lebih rapi.</dd>
</dl>
<dl>
<dt>akun.php</dt>
<dd>File akun.php adalah tempat untuk mengelola semua data yang berhubungan dengan akun.</dd>
</dl>
<dl>
<dt>conf.php</dt>
<dd>File conf.php adalah file untuk konfigurasi koneksi ke database dan fungsi base url.</dd>
</dl>
<dl>
<dt>dashboard.php</dt>
<dd>File dashboard.php ada file untuk mengolah semua data, menambah, merubah, dan menghapus data.</dd>
</dl>
<dl>
<dt>data.php</dt>
<dd>File data.php adalah file untuk menampilkan data. Bersifat privat khusus anggota.</dd>
</dl>
<dl>
<dt>detail.php</dt>
<dd>File detail.php adalah file untuk menampilkan detail data. Bersifat privat khusus anggota.</dd>
</dl>
<dl>
<dt>edit-data.php</dt>
<dd>File edit-data.php adalah file untuk merubah data. Bersifat privat khusus anggota.</dd>
</dl>
<dl>
<dt>footer-kons.php</dt>
<dd>File footer.php adalah file untuk menampilkan footer atau bagian paling bawah dan sekalian untuk bagian sidebar web. Bersifat publik.</dd>
</dl>
<dl>
<dt>footer.php</dt>
<dd>File footer.php adalah file untuk menampilkan footer atau bagian paling bawah web. Bersifat privat khusus anggota.</dd>
</dl>
<dl>
<dt>header-kons.php</dt>
<dd>File header-kons.php adalah file untuk menampilkan header atau bagian paling atas web. Bersifat publik.</dd>
</dl>
<dl>
<dt>header.php</dt>
<dd>File header.php adalah file untuk menampilkan header atau bagian pling atas web. Bersifat privat khusus anggota.</dd>
</dl>
<dl>
<dt>hlm.php</dt>
<dd>File hlm.php adalah file untuk menampilkan halaman statis. Bersifat publik namun lebih dikhususkan untuk anggota.</dd>
</dl>
<dl>
<dt>index.php</dt>
<dd>File index.php adalah file utama untuk menampilkan semua data. Bersifat publik dan privat kusus anggota.</dd>
</dl>
<dl>
<dt>keluar.php</dt>
<dd>File keluar.php adalah file khusus untuk proses keluar atau logout dan membersihkan semua sesi yang ada. Bersifat khusus yang masuk atau login.</dd>
</dl>
<dl>
<dt>konsumsi.php</dt>
<dd>File konsumsi.php adalah file untuk menampilkan seluruh data posting. Bersifat publik.</dd>
</dl>
<dl>
<dt>preview.php</dt>
<dd>File preview.php adalah file untuk menampilkan preview posting yang sedang ditulis atau diedit. Bersifat privat khusus pengguna terdaftar dan aktif.</dd>
</dl>
<dl>
<dt>proses.php</dt>
<dd>File proses.php adalah file khusus untuk memproses seluruh data yang dikirim akan diterima dan diproses di file ini dan hasil proses akan dikembalikan ke file tujuan. Bersifat privat dan publik.</dd>
</dl>
<dl>
<dt>tambah-data.php</dt>
<dd>File tambah-data.php adalah file untuk menambah data. Bersifat privat khusus anggota.</dd>
</dl>
<dl>
<dt>umum.php</dt>
<dd>File umum.php adalah file untuk menampilkan data halaman statis. Bersifat publik.</dd>
</dl>
<dl>
<dt>upart.php</dt>
<dd>File upart.php adalah file untuk upload gambar, dikhususkan untuk gambar posting. Bersifat privat khusus pengguna terdaftar dan aktif.</dd>
</dl>
</ul>

<p>Oh iya sebelumnya saya ingin memberitahukan bahwa saya sudah mempersiapkan semua data dan file mentahnya. Bagi teman-teman yang sengkiranya membutuhkan untuk dipakai langsung atau hanya sekedar untuk bahan pembelajaran bisa teman-teman dapatkan dibagian paling bawah halaman ini.</p>

<p>File mentah ini saya sudah saya siapkan dengan 2 pilihan, pilihan pertama berbentuk teks yang dapat teman-teman copas, dan yang satunya pilihan saya kemas dalam bentuk file .zip yang dapat teman-teman download langsung ke perangkat masing-masing.</p>

<p>Sekarang saya lanjut kebagian kedua halaman ini, dimana pasa bagian ini saya akan mejelaskan fitur-fitur apa saja yang ada lengkap dengan detail aksesnya </p>

</body>
</html>
